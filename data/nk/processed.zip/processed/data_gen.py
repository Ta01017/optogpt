import numpy as np
import pandas as pd
import random
import os
from tqdm import tqdm
from scipy.interpolate import interp1d
from tmm import coh_tmm
import pickle as pkl

# ============================================================
# 1. 全局配置
# ============================================================

NUM_SAMPLES = 1000

PAIR_MIN = 6
PAIR_MAX = 10

WAVELENGTHS = np.arange(0.8, 1.7, 0.005)  # um
LAMBDA0_RANGE = (0.9, 1.5)                # um

PERTURB_STD = 0.01
PERTURB_RANDOM = 0.1

DBR_MATERIAL_PAIRS = [
    ('TiO2', 'SiO2'),
    ('Ta2O5', 'SiO2'),
    ('HfO2', 'SiO2')
]

SUBSTRATE = 'Glass_Substrate'
SUBSTRATE_THICKNESS = 500000  # nm

NK_DIR = './data/nk/processed'
OUT_DIR = './output'
os.makedirs(OUT_DIR, exist_ok=True)

# ============================================================
# 2. nk 数据加载
# ============================================================


import matplotlib.pyplot as plt

def visualize_one_dbr(nk_dict):
    mats, thks, lambda0, mode = generate_dbr(nk_dict)
    R = calc_reflectance(mats, thks, nk_dict)

    wl_nm = (WAVELENGTHS * 1000)

    plt.figure(figsize=(7, 4))
    plt.plot(wl_nm, R, lw=2, label='Reflectance R')
    plt.axvline(lambda0 * 1000, ls='--', c='r', label=f'λ₀ = {int(lambda0*1000)} nm')

    plt.ylim(0, 1.05)
    plt.xlabel('Wavelength (nm)')
    plt.ylabel('Reflectance')
    plt.title(f'DBR Spectrum | {mode} | {len(mats)//2} pairs')
    plt.grid(alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.show()

    print("Structure:")
    for m, t in zip(mats, thks):
        print(f"{m:6s}  {t:.1f} nm")


def load_nk(materials, wavelengths):
    nk = {}
    for mat in materials:
        df = pd.read_csv(os.path.join(NK_DIR, mat + '.csv'))
        wl = df['wl'].values
        n = df['n'].values
        k = df['k'].values

        n_interp = interp1d(wl, n, bounds_error=False, fill_value='extrapolate')
        k_interp = interp1d(wl, k, bounds_error=False, fill_value='extrapolate')

        nk[mat] = n_interp(wavelengths) + 1j * k_interp(wavelengths)
    return nk

# ============================================================
# 3. DBR 结构生成
# ============================================================

def generate_dbr(nk_dict):
    H, L = random.choice(DBR_MATERIAL_PAIRS)
    lambda0 = random.uniform(*LAMBDA0_RANGE)
    pairs = random.randint(PAIR_MIN, PAIR_MAX)

    if random.random() < 0.3:
        perturb = PERTURB_STD
        mode = 'standard'
    else:
        perturb = PERTURB_RANDOM
        mode = 'random'

    materials = []
    thicknesses = []

    idx0 = np.argmin(np.abs(WAVELENGTHS - lambda0))

    for i in range(pairs * 2):
        mat = H if i % 2 == 0 else L
        n_real = np.real(nk_dict[mat][idx0])

        d = lambda0 * 1000 / (4 * n_real)
        d *= random.uniform(1 - perturb, 1 + perturb)

        materials.append(mat)
        thicknesses.append(d)

    return materials, thicknesses, lambda0, mode

# ============================================================
# 4. DBR 光谱计算（coh TMM）
# ============================================================

def calc_reflectance(materials, thicknesses, nk_dict):
    R = []
    d_list = [np.inf] + thicknesses + [np.inf]

    for i, wl_nm in enumerate((WAVELENGTHS * 1000).astype(int)):
        n_list = [1] + [nk_dict[m][i] for m in materials] + [1]

        res = coh_tmm(
            pol='s',
            n_list=n_list,
            d_list=d_list,
            th_0=0,
            lam_vac=wl_nm
        )
        R.append(res['R'])

    return R

# ============================================================
# 5. 数据集生成
# ============================================================

def generate_dataset():
    print("Loading nk data...")
    mats = list(set([m for p in DBR_MATERIAL_PAIRS for m in p]))
    nk = load_nk(mats, WAVELENGTHS)

    records = []

    for _ in tqdm(range(NUM_SAMPLES)):
        try:
            mats, thks, lambda0, mode = generate_dbr(nk)
            R = calc_reflectance(mats, thks, nk)

            rec = {
                'structure': [f'{m}_{int(round(t))}' for m, t in zip(mats, thks)],
                'num_layers': len(mats),
                'lambda0_nm': int(lambda0 * 1000),
                'mode': mode
            }

            for wl, r in zip((WAVELENGTHS * 1000).astype(int), R):
                rec[f'R_{wl}nm'] = r

            records.append(rec)

        except Exception:
            continue

    df = pd.DataFrame(records)

    df.to_csv(os.path.join(OUT_DIR, 'dbr_dataset.csv'), index=False)
    df.to_pickle(os.path.join(OUT_DIR, 'dbr_dataset.pkl'))

    with open(os.path.join(OUT_DIR, 'train_structure.pkl'), 'wb') as f:
        pkl.dump(df['structure'].tolist(), f)

    spectra_cols = [c for c in df.columns if c.startswith('R_')]
    with open(os.path.join(OUT_DIR, 'train_spectrum.pkl'), 'wb') as f:
        pkl.dump(df[spectra_cols].values.tolist(), f)

    print(f"✔ DBR dataset generated: {len(df)} samples")

# ============================================================
# 6. 主入口
# ============================================================

if __name__ == '__main__':
    mats = list(set([m for p in DBR_MATERIAL_PAIRS for m in p]))
    nk = load_nk(mats, WAVELENGTHS)

    # 画 3 个 DBR 做 sanity check
    for _ in range(10):
        visualize_one_dbr(nk)
    # generate_dataset()
